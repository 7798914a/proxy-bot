
DATA_FILE = "data.json" #user data save file (absolute path)
TGPROXY_FILE = "tgproxy.txt" #mtproxy data save file (absolute path)
PROXY_FILE = "proxy.txt" #proxy data save file (absolute path)
POINTS_PER_DAY = 1 #please do not modify
NEWS = "" # /proxy and /tgproxy bottom message

token = "" # telegram bot token
adminlist = [114, 514] # admin telegram ID

backend = ["https://api.ffq.la/", "https://subscribe.cctv.rip/", "https://api.v1.mk/"] #subscribe convert backend api
ini = "https://raw.githubusercontent.com/ACL4SSR/ACL4SSR/master/Clash/config/ACL4SSR_Online.ini" #subscribe convert config
